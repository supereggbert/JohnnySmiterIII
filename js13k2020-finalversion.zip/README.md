# Johnny Smiter Episdoe 0
*js13kgames entry for 2019*
https://2019.js13kgames.com

Code Used:
https://aframe.io
https://threejs.org
https://sb.bitsnbites.eu

# About the Game
Johnny Smiter Episode Zero is a prequel in the Johnny Smiter series. It takes things back to the beginning, telling the origin story of the 13th Knight. You are a lowly huntsman in this episode, battling the evils of the 13th Realm for the first time. Remember to always watch your back as evil will emerge from the darkness, hungry for your blood.

WARNINGS: 
This game is not suitable for arachnophobes.
Parental Guidance is recommend for under 13s due to the high level of gore.

**Best experienced in room scale**
